const SmallBtn = (props) => {
  const { label, clickHandler } = props;
  return (
    <>
      <button
        className="px-4 py-2 font-semibold text-center text-white uppercase rounded-md text-size-14 bg-gray-600 flex items-center ml-5 cursor-pointer"
        onClick={clickHandler}
      >
        {label}
      </button>
    </>
  );
};
export default SmallBtn;
