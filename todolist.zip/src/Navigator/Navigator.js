import React from "react-dom";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import TodoList from "../pages/TodoList";
const Navigator = () => {
  return (
    <>
      <Router>
        <Routes>
          <Route path="/" element={<TodoList />} exact></Route>
        </Routes>
      </Router>
    </>
  );
};
export default Navigator;
