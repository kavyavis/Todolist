import Navigator from "./Navigator/Navigator";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "./globals.css";
function App() {
  return (
    <div className="App">
      <Navigator />
      <ToastContainer />
    </div>
  );
}
export default App;
