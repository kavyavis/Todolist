import { toast } from "react-toastify";

export const successToast = (title) => {
  toast.success(title);
};

export const errorToast = (title) => {
  toast.error(title);
};
