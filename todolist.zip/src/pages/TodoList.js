import React, { useState, useEffect } from "react";
import SmallBtn from "../components/SmallBtn/SmallBtn";
import { toast } from "react-toastify";
import { successToast } from "../common/Helper";

const TodoList = () => {
  const [todos, setTodos] = useState([]);
  const [inputValue, setInputValue] = useState("");

  useEffect(() => {
    const todosLocal = JSON.parse(localStorage.getItem("todosLocal"));
    if (todosLocal) {
      setTodos(todosLocal);
    }
  }, []);

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };

  const addTodoHandler = (e) => {
    e.preventDefault();

    // Trim the inputValue to remove leading and trailing whitespace
    const trimmedValue = inputValue.trim();

    if (trimmedValue === "") {
      toast.error("Please enter a valid todo.");
      return;
    }

    // Create a new todo object with the trimmed value and initial 'done' status
    const newTodo = { task: trimmedValue, done: false };

    // Update the todos state by appending the new todo
    const newTodos = [...todos, newTodo];
    setTodos(newTodos);

    // Update localStorage with the updated todos array
    localStorage.setItem("todosLocal", JSON.stringify(newTodos));

    // Clear the inputValue state for the next todo
    setInputValue("");
    successToast("Todo added successfully");
  };

  const handleCheckBoxChange = (index) => {
    const updatedTodos = [...todos];
    updatedTodos[index].done = !updatedTodos[index].done;
    setTodos(updatedTodos);
    localStorage.setItem("todosLocal", JSON.stringify(updatedTodos));
  };

  const deleteHandler = (index) => {
    const updatedTodos = [...todos];
    updatedTodos.splice(index, 1);
    setTodos(updatedTodos);
    localStorage.setItem("todosLocal", JSON.stringify(updatedTodos));
    successToast("Todo deleted successfully");
  };

  const deleteAllTodos = () => {
    setTodos([]);
    localStorage.removeItem("todosLocal");
    successToast("All todos deleted");
  };

  return (
    <div className="w-[800px] mx-auto p-12 my-12 bg-gray-200 rounded-lg ">
      <h1 className="text-black text-2xl mb-4 font-semibold">To Do List</h1>
      <form onSubmit={addTodoHandler} className="flex my-2">
        <input
          type="text"
          placeholder="Add New List Item"
          className="p-4 font-semibold text-left rounded-md text-size-14 focus:outline-none w-full text-zinc-600"
          value={inputValue}
          onChange={handleInputChange}
        />
        <SmallBtn label={"Add"} clickHandler={addTodoHandler} />
      </form>
      <div>
        {todos.map((todo, index) => (
          <div
            className="px-2 py-3 flex items-center justify-between my-2"
            key={index}
          >
            <div className="flex items-center">
              <input
                type="checkbox"
                className="p-2 accent-gray-600 w-5 h-5 rounded-md cursor-pointer"
                checked={todo.done}
                onChange={() => handleCheckBoxChange(index)}
              />
              <p
                className={`text-left text-gray-500 text-size-16 pl-2 ${
                  todo.done ? "line-through" : ""
                }`}
              >
                {todo.task}
              </p>
            </div>
            <div className="flex">
              <SmallBtn
                label={"Delete"}
                clickHandler={() => deleteHandler(index)}
              />
            </div>
          </div>
        ))}
      </div>
      <div className="w-full flex justify-end mt-8">
        <button
          className="px-4 py-2 font-semibold text-center text-white uppercase rounded-md text-size-14 bg-red-400 flex items-center ml-5 cursor-pointer"
          onClick={deleteAllTodos}
        >
          Clear All
        </button>
      </div>
    </div>
  );
};

export default TodoList;
